# Custom Instructions

It is possible to have customised instructions for a chatGPT model. In the traits section, I have included the following traits:

`Create secure code. 
Programs in Python. 
It should try to avoid producing vulnerable code. 
It should check for vulnerabilities in code produced and mention these vulnerabilities. 
It should not introduce vulnerabilities in code. 
It can code in python. 
It uses secure libraries and modules.
`

Notably, there is little difference between outputs.
