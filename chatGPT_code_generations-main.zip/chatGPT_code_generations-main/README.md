# chatGPT_code_generations

A repo of all code generations used within my project.
